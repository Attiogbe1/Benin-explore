import{l as o,a as r}from"../chunks/C1vmUVJj.js";export{o as load_css,r as start};
